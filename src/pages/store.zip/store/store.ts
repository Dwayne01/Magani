import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

/*
  Generated class for the Store page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-store',
  templateUrl: 'store.html'
})
export class StorePage {
	public drugs: Array<any>;
	public items: Array<number>;
  
  constructor(public navCtrl: NavController) {
    
  	this.items = [];
  	this.drugs = [
  		{
  			id: 1,
  			name: "Cough Syrup",
  			description: "1 mg",
  			category: "Sniffler",
  			imageURL: "../../assets/img/hyl-75241-3m.jpg",
  			added: false,
  		},
  		{
  			id: 2,
  			name: "Cough Syrup",
  			description: "1 mg",
  			category: "Sniffler",
  			imageURL: "../../assets/img/hyl-75241-3m.jpg",
  			added: false,
  		},
  		{
  			id: 3,
  			name: "Cough Syrup",
  			description: "1 mg",
  			category: "Sniffler",
  			imageURL: "../../assets/img/hyl-75241-3m.jpg",
  			added: false,
  		},
  		{
  			id: 4,
  			name: "Cough Syrup",
  			description: "1 mg",
  			category: "Sniffler",
  			imageURL: "../../assets/img/hyl-75241-3m.jpg",
  			added: false,
  		},
      {
        id: 5,
        name: "Cough Syrup",
        description: "1 mg",
        category: "Sniffler",
        imageURL: "../../assets/img/hyl-75241-3m.jpg",
        added: false,
      },

  	]
  }
  
  public addToCart (stuff) {
  		stuff.added = !stuff.added;


  		
  		if ( stuff.added === true) {
  			this.items.push(stuff.id);
  		} else {
  			let x: number = this.items.indexOf(stuff.id);
  			this.items.splice(x, 1);
  		}

  		
  }

}

